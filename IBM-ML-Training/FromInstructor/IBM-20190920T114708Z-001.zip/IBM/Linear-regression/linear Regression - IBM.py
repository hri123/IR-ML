import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

###############LAB:Correlation Calculation########################

#Dataset: Air Travel Data\Air_travel.csv
#Importing Air passengers data
air = pd.read_csv("C:\\Users\\Admin\\Documents\\Kiran\\Documents\\Kiran\\Accenture\\Python\\IBM\\Linear Regression\\Datasets\\AirPassengers\\AirPassengers.csv")
air.shape
air.columns.values
air.head(10)
air.describe()

#Find the correlation between number of passengers and promotional budget.
np.corrcoef(air.Passengers, air.Promotion_Budget)

#Draw a scatter plot between number of passengers and promotional budget
plt.scatter(air.Passengers, air.Promotion_Budget)

#Find the correlation between number of passengers and Service_Quality_Score
np.corrcoef(air.Passengers,air.Service_Quality_Score)


#Correlation between promotion and passengers count
np.corrcoef(air.Passengers,air.Promotion_Budget)

#Draw a scatter plot between   Promotion_Budget and Passengers. Is there any any pattern between Promotion_Budget and Passengers?
plt.scatter(air.Promotion_Budget,air.Passengers)

#Build a linear regression model and estimate the expected passengers for a Promotion_Budget is 650,000
##Regression Model  promotion and passengers count
import statsmodels.api as sm

y =air[['Passengers']]
X = air[['Promotion_Budget']]

X1 = sm.add_constant(X)

# Modelling using ordinary Least squaring methid (OLS )
model = sm.OLS(y, X1)

fitted1 = model.fit()
fitted1.summary()

# Regression Line
plt.scatter(air.Promotion_Budget,air.Passengers)
plt.plot(air.Promotion_Budget, fitted1.fittedvalues, c='r')

#Estimating passengers value if promotional budget is 650000
fitted1.predict([1,650000])
