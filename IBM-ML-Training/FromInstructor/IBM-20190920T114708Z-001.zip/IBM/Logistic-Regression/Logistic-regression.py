﻿
##############################################################################
####################### logistic Regresssion ###################################

##### LAB-What is the need of logistic regression ################

#Import the Dataset: Product Sales Data/Product_sales.csv
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
sales=pd.read_csv("C:\\Users\\Admin\\Documents\\Kiran\\Documents\\Kiran\\Accenture\\Python\\IBM\\Logistic Regression\\Session-2.Logistic-Regression-Datasets\\Datasets\\Product Sales Data\\Product_sales.csv")

#What are the variables in the dataset? 
sales.columns.values

#Build a predictive model for Bought vs Age
### we need to use the statsmodels package, which enables many statistical methods to be used in Python
import statsmodels.api as sm
model = sm.OLS(sales[["Bought"]], sm.add_constant(sales[["Age"]]))
fitted = model.fit()
fitted.summary()

#If Age is 4 then will that customer buy the product?

age1=4
predict1=fitted.predict([1, age1])
predict1
### for age=4 value is less than zero  

sales.Bought.value_counts()
#If Age is 105 then will that customer buy the product?
age2=105
predict2=fitted.predict([1, age2])
predict2

##### for age=105 value is greater than one.

##Let's look at the data and our regression line
plt.scatter(sales.Age, sales.Bought)
plt.plot(sales.Age, fitted.fittedvalues, c='r')
#######From this linear regression,we can not interpret whether a person buys or not

################ Lab: Logistic Regression ######################

#Dataset: Product Sales Data/Product_sales.csv
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
sales=pd.read_csv("C:\\Users\\Admin\\Documents\\Kiran\\Documents\\Kiran\\Accenture\\Python\\IBM\\Logistic Regression\\Session-2.Logistic-Regression-Datasets\\Datasets\\Product Sales Data\\Product_sales.csv")

#Checking the linear line
import statsmodels.api as sm

linear=sm.OLS(sales['Bought'], sm.add_constant(sales['Age'])).fit()

X_plot = np.linspace(1,65, 467)
plt.scatter(sales.Age, sales.Bought)
plt.plot(X_plot, linear.predict(sm.add_constant(X_plot)), c='r')

# Build a logistic Regression line between Age and buying

logit=sm.Logit(sales['Bought'], sm.add_constant(sales['Age'])).fit()
logit.summary()

#One more way of fitting the model
#A 4 years old customer, will he buy the product?
age1=4
predict_age1=logit.predict([1,age1])
predict_age1

#If Age is 105 then will that customer buy the product?
age2=105
predict_age2=logit.predict([1, age2])
predict_age2

### Plotting

plt.scatter(sales.Age, sales.Bought)
plt.plot(X_plot, linear.predict(sm.add_constant(X_plot)), c='r')
plt.plot(X_plot, logit.predict(sm.add_constant(X_plot)), c='g')


###########
#One more way of fitting the model
from sklearn.linear_model import LogisticRegression
logistic = LogisticRegression()
logistic.fit(sales[["Age"]],sales["Bought"])

#A 4 years old customer, will he buy the product?
age1=4
predict_age1=logistic.predict(age1)
print(predict_age1)

#If Age is 105 then will that customer buy the product?
age2=105
predict_age2=logistic.predict(age2)
print(predict_age2)


##############LAB: Multiple Logistic Regression####################

#Dataset: Fiberbits/Fiberbits.csv
Fiber=pd.read_csv("C:\\Users\\Admin\\Documents\\Kiran\\Documents\\Kiran\\Accenture\\Python\\IBM\\Logistic Regression\\Session-2.Logistic-Regression-Datasets\\Datasets\\Fiberbits\\Fiberbits.csv")
list(Fiber.columns.values)  ###to get variables list

#Build a model to predict the chance of attrition for a given customer using all the features. 
 ###fitting logistic regression for active customer on rest of the varibles#######
import statsmodels.api as sm

y = Fiber[['active_cust']]
X  = Fiber[["income"]+['months_on_network']+['Num_complaints']+['number_plan_changes']+['relocated']+['monthly_bill']+['technical_issues_per_month']+['Speed_test_result']]
 
logit = sm.Logit(y, sm.add_constant(X)).fit()

#What are the most impacting variables?
logit.summary2()
#### From summary of the model
#For all the variables p<0.05,so all are impacting

##Building the Logistic Regression Model from SKlearn
#Build a model to predict the chance of attrition for a given customer using all the features. 
from sklearn.linear_model import LogisticRegression
logistic1= LogisticRegression()
###fitting logistic regression for active customer on rest of the varibles#######
logistic1.fit(X,y)

predict1=logistic1.predict(X)
predict1


###############LAB: Confusion Matrix & Accuracy ########################


#Create confusion matrix for Fiber bits model

from sklearn.metrics import confusion_matrix###for using confusion matrix###
cm1 = confusion_matrix(Fiber[['active_cust']],predict1)
print(cm1)

#find the accuracy value for fiber bits model
total1 = sum(sum(cm1))
#####from confusion matrix calculate accuracy
accuracy1=(cm1[0,0]+cm1[1,1])/total1
accuracy1

##Or I can just use Score Function
logistic1.score(X,y)



###################LAB: Individual Impact of Variables################

#Identify top impacting and least impacting variables in fiber bits models
####Variable importance is decided from Wald chi‐square value i.e square of Z parameter.
##from summary,sort the varibles in the order of the squares of their z values.
#Find the variable importance and order them based on their impact


########  LAB-Logistic Regression Model Selection ###########

#Find AIC and BIC values for the first fiber bits model(m1)
#Including all the variables
m1=sm.Logit(Fiber['active_cust'],Fiber[["income"]+['months_on_network']+['Num_complaints']+['number_plan_changes']+['relocated']+['monthly_bill']+['technical_issues_per_month']+['Speed_test_result']])
m1
m1.fit()
m1.fit().summary()
m1.fit().summary2()

#What are the top-2 impacting variables in fiber bits model?

#What are the least impacting variables in fiber bits model?
#Can we drop any of these variables and build a new model(m2)
#Income and Monthly Bill Dropped
m2=sm.Logit(Fiber['active_cust'],Fiber[['months_on_network']+['Num_complaints']+['number_plan_changes']+['relocated']+['technical_issues_per_month']+['Speed_test_result']])
m2
m2.fit()
m2.fit().summary()
m2.fit().summary2()

#We have two models, what the best accuracy that you can expect on this data

#Dropping high impacting variables 
#relocated and Speed_test_result dropped
m3=sm.Logit(Fiber['active_cust'],Fiber[["income"]+['months_on_network']+['Num_complaints']+['number_plan_changes']+['monthly_bill']+['technical_issues_per_month']])
m3
m3.fit()
m3.fit().summary()
m3.fit().summary2()



