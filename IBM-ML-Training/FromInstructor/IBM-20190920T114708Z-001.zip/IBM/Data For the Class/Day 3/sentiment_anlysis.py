##from textblob import TextBlob
##
##Feedback1 = "The food in Mariot is awesome"
##Feedback2 = "The food in Mariot is very bad"
##blob1  = TextBlob(Feedback1)
##blob2  = TextBlob(Feedback2)
##
##print(blob1.sentiment)
##print(blob2.sentiment)


##################
# twitter sentiment analysis


import tweepy
# If import of tweepy is a givig issues in v3.7,
# pip install -U git+https://github.com/tweepy/tweepy.git
# for which u need to install Git software from https://git-scm.com/downloads


from textblob import TextBlob
consumer_key = '1vbmQb5yuIvPuBD2OSb9hE8FT'
consumer_secret  = '4rKUALXVAq22xDKVuNVhFRHP8TrDwWWjEcnzedtWoiIj7G4fcE'
access_token = '88174089-ZTy5i1OzeBqZTK0S8tw66Veica1V61FBI9M9bQIm2'
access_token_secret = 'ADkRu4MKRDX22OsUWMc0msPN9zALiPKPQwibOSKwh1iAd'
auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)
api = tweepy.API(auth)
public_tweets = api.search('trump')
for tweet in public_tweets:
    print(tweet.text)
    analysis = TextBlob(tweet.text)
    print(analysis.sentiment)
    

